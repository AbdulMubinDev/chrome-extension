(function () {
  if (window.fbEngagerContentScriptLoaded) return;
  window.fbEngagerContentScriptLoaded = true;

  // ✅ FIX #2: Added ALL missing initialization properties
  const state = {
    isInitialized: false,
    debugMode: false,
    extractedUsernames: new Set(),
    lastExtractionTime: 0,
    extractionCount: 0,
    cooldownSetting: 25,
    extractionCountLimit: 50,
    currentPostId: null,
    modalObserver: null,
    feedObserver: null, // ✅ FIX #3: Consistent naming (was feedPostObserver)
    statsUpdateInterval: null, // ✅ FIX #4: Consistent naming (was statsInterval)
    cleanupInterval: null,
    lastModalStatus: { modalDetected: false, modalType: null, postId: null },
    initializationAttempts: 0, // ✅ FIX #2: Added missing property
    maxInitAttempts: 5, // ✅ FIX #2: Added missing property
    dynamicCommentObserver: null, // ✅ FIX #11: Added missing property
    scrollListener: null,
    lastStatsUpdate: 0,
    lastScrollTime: 0,
    modalContentObserver: null,
    statusCheckInterval: null,
    lastObservedPost: null,
    posterName: null,
    lastDomStructureHash: null,
    domChangeCount: 0,
    domWarningShown: false,
    modalPostInfo: null,
    modalPostDetected: false,
    memoryCleanupInterval: null,
  };

  // ✅ FIX #19: Single debug flag (was DEBUG_MODE and state.debugMode)
  let DEBUG_MODE = false;

  // ✅ FIX #6: Added error handling for storage operations
  chrome.storage.local.get(
    [
      "debugMode",
      "extractedUsernames",
      "lastExtractionTime",
      "extractionCount",
      "cooldownSetting",
      "extractionCountLimit",
    ],
    (result) => {
      if (chrome.runtime.lastError) {
        console.warn("Storage read error:", chrome.runtime.lastError.message);
        return;
      }

      DEBUG_MODE = state.debugMode = result.debugMode || false;
      if (result.extractedUsernames)
        state.extractedUsernames = new Set(result.extractedUsernames);
      state.lastExtractionTime = result.lastExtractionTime || 0;
      state.extractionCount = result.extractionCount || 0;
      state.cooldownSetting = result.cooldownSetting || 25;
      state.extractionCountLimit = result.extractionCountLimit || 50;
    }
  );

  // ✅ FIX #13: Added debouncing to prevent excessive post change calls
  let postChangeDebounceTimer = null;
  function handlePostChange(newPostInfo) {
    if (postChangeDebounceTimer) {
      clearTimeout(postChangeDebounceTimer);
    }

    postChangeDebounceTimer = setTimeout(() => {
      const currentPostId = state.currentPostId;
      const newPostId = newPostInfo?.postId || null;

      if (DEBUG_MODE) {
        console.log(
          `[POST_CHANGE] Checking post change: current=${currentPostId}, new=${newPostId}`
        );
      }

      if (currentPostId !== newPostId) {
        if (DEBUG_MODE) {
          console.log(
            `[POST_CHANGE] Post changed from ${currentPostId} to ${newPostId}`
          );
        }

        state.lastModalStatus = {
          modalDetected: false,
          modalType: null,
          postId: null,
        };

        state.currentPostId = newPostId;

        safeSendMessage({
          action: "postChanged",
          oldPost: { postId: currentPostId },
          newPost: newPostInfo,
        });
      } else {
        if (DEBUG_MODE) {
          console.log(
            `[POST_CHANGE] Post ID same (${currentPostId}), no update needed`
          );
        }
      }
    }, 300); // ✅ FIX #13: 300ms debounce
  }

  function sendStatsUpdate() {
    try {
      const modalStatus = checkModalStatus();
      const stats = {
        totalComments:
          modalStatus.modalDetected && modalStatus.modalType === "Comments"
            ? modalStatus.totalComments || 0
            : 0,
        capturedUsernames: state.extractedUsernames.size,
        isExtracting: false,
        lastUpdate: Date.now(),
      };

      safeSendMessage({
        action: "statsUpdate",
        stats: stats,
      });
    } catch (error) {
      if (DEBUG_MODE) console.log("Error sending stats update:", error);
    }
  }

  // ✅ FIX #18: Standardized timing to 1000ms updates, 2000ms interval
  function startStatsUpdates() {
    if (state.statsUpdateInterval) return; // Already running

    state.statsUpdateInterval = setInterval(() => {
      const now = Date.now();
      const timeSinceLastUpdate = now - (state.lastStatsUpdate || 0);

      if (timeSinceLastUpdate >= 1000) {
        // ✅ Consistent 1000ms
        const modalStatus = checkModalStatus();
        if (modalStatus.modalDetected && modalStatus.modalType === "Comments") {
          sendStatsUpdate();
          state.lastStatsUpdate = now;
        }
      }
    }, 2000); // ✅ Consistent 2000ms check interval

    if (DEBUG_MODE) console.log("Started periodic stats updates");
  }

  // ✅ FIX #11 & #12: Proper initialization with duplicate check
  function startDynamicCommentCounting() {
    if (state.dynamicCommentObserver || state.scrollListener) return; // ✅ Prevent duplicates

    const modal =
      document.querySelector('[role="dialog"]') ||
      document.querySelector('[aria-modal="true"]') ||
      document.querySelector('div[data-visualcompletion="ignore-dynamic"]') ||
      document.querySelector("div[data-pagelet][data-visualcompletion]");

    if (!modal) return;

    state.dynamicCommentObserver = new MutationObserver((mutations) => {
      let hasNewComments = false;

      for (const mutation of mutations) {
        if (mutation.type === "childList" && mutation.addedNodes.length > 0) {
          for (const node of mutation.addedNodes) {
            if (node.nodeType === Node.ELEMENT_NODE) {
              if (
                node.matches(
                  '[data-testid*="comment"], div[role="article"], [data-commentid"], [data-testid*="Comment"]'
                ) ||
                node.querySelector(
                  '[data-testid*="comment"], div[role="article"], [data-commentid]'
                )
              ) {
                hasNewComments = true;
                break;
              }
            }
          }
        }
      }

      if (hasNewComments) {
        const now = Date.now();
        const timeSinceLastUpdate = now - (state.lastStatsUpdate || 0);

        if (timeSinceLastUpdate >= 500) {
          const modalStatus = checkModalStatus();
          if (
            modalStatus.modalDetected &&
            modalStatus.modalType === "Comments"
          ) {
            sendStatsUpdate();
            state.lastStatsUpdate = now;
          }
        }
      }
    });

    state.dynamicCommentObserver.observe(modal, {
      childList: true,
      subtree: true,
    });

    // ✅ FIX #12: Check before adding scroll listener
    state.scrollListener = () => {
      const now = Date.now();
      const timeSinceLastScroll = now - (state.lastScrollTime || 0);

      if (timeSinceLastScroll >= 200) {
        const modalStatus = checkModalStatus();
        if (modalStatus.modalDetected && modalStatus.modalType === "Comments") {
          const scrollTop = modal.scrollTop;
          const scrollHeight = modal.scrollHeight;
          const clientHeight = modal.clientHeight;

          if (scrollHeight - scrollTop - clientHeight < 200) {
            loadMoreContentFast(modal);
          }

          const timeSinceLastUpdate = now - (state.lastStatsUpdate || 0);
          if (timeSinceLastUpdate >= 1000) {
            sendStatsUpdate();
            state.lastStatsUpdate = now;
          }
        }
        state.lastScrollTime = now;
      }
    };

    modal.addEventListener("scroll", state.scrollListener, { passive: true });

    if (DEBUG_MODE) console.log("Started dynamic comment counting");
  }

  function stopDynamicCommentCounting() {
    if (state.dynamicCommentObserver) {
      state.dynamicCommentObserver.disconnect();
      state.dynamicCommentObserver = null;
    }

    if (state.scrollListener) {
      const modal =
        document.querySelector('[role="dialog"]') ||
        document.querySelector('[aria-modal="true"]') ||
        document.querySelector('div[data-visualcompletion="ignore-dynamic"]') ||
        document.querySelector("div[data-pagelet][data-visualcompletion]");

      if (modal) {
        modal.removeEventListener("scroll", state.scrollListener);
      }
      state.scrollListener = null;
    }

    if (DEBUG_MODE) console.log("Stopped dynamic comment counting");
  }

  function stopStatsUpdates() {
    if (state.statsUpdateInterval) {
      clearInterval(state.statsUpdateInterval);
      state.statsUpdateInterval = null;
      if (DEBUG_MODE) console.log("Stopped periodic stats updates");
    }
  }

  window.addEventListener("unload", () => {
    if (state.modalObserver) {
      state.modalObserver.disconnect();
      state.modalObserver = null;
    }
    if (state.modalContentObserver) {
      state.modalContentObserver.disconnect();
      state.modalContentObserver = null;
    }
    if (state.statusCheckInterval) {
      clearInterval(state.statusCheckInterval);
      state.statusCheckInterval = null;
    }
    stopStatsUpdates();
    stopDynamicCommentCounting();
  });

  document.addEventListener("visibilitychange", () => {
    if (document.hidden) {
      // Reduce resource usage when tab is not visible
    }
  });

  function checkFacebookPageHealth() {
    try {
      const criticalSelectors = ["body", "[data-testid]"];
      let healthScore = 0;
      const issues = [];

      for (const selector of criticalSelectors) {
        const elements = document.querySelectorAll(selector);
        if (elements.length === 0) {
          issues.push(`Missing: ${selector}`);
        } else {
          healthScore += 1;
        }
      }

      const hasRecentErrors = window.__fbErrors && window.__fbErrors.length > 0;
      const isLoading = document.readyState !== "complete";

      const healthStatus = {
        score: healthScore / criticalSelectors.length,
        issues,
        hasRecentErrors,
        isLoading,
        isHealthy: healthScore >= 1 && !isLoading,
      };

      if (DEBUG_MODE) console.log("Facebook page health check:", healthStatus);
      return healthStatus;
    } catch (error) {
      if (DEBUG_MODE) console.log("Error checking Facebook health:", error);
      return {
        score: 0,
        issues: ["Health check failed"],
        hasRecentErrors: true,
        isLoading: false,
        isHealthy: false,
      };
    }
  }

  function initializeContentScript() {
    if (state.isInitialized) return;

    const attempts = state.initializationAttempts + 1;
    state.initializationAttempts = attempts;

    try {
      if (!window.location.hostname.includes("facebook.com")) {
        if (DEBUG_MODE) console.log("Not on Facebook, skipping initialization");
        return;
      }

      const healthStatus = checkFacebookPageHealth();
      if (!healthStatus.isHealthy) {
        if (DEBUG_MODE)
          console.log(
            "Facebook page not healthy, delaying initialization:",
            healthStatus
          );
        if (attempts < state.maxInitAttempts) {
          setTimeout(initializeContentScript, 2000);
        } else {
          console.warn(
            "Failed to initialize due to Facebook page health issues after",
            state.maxInitAttempts,
            "attempts"
          );
        }
        return;
      }

      if (
        document.readyState !== "complete" &&
        document.readyState !== "interactive"
      ) {
        if (attempts < state.maxInitAttempts) {
          setTimeout(initializeContentScript, 500);
        } else {
          console.warn(
            "Failed to initialize content script after",
            state.maxInitAttempts,
            "attempts"
          );
        }
        return;
      }

      state.isInitialized = true;
      if (DEBUG_MODE)
        console.log(
          "Content script initialized successfully on:",
          window.location.href
        );

      setupModalDetectionObserver();
      setupFeedPostObserver();

      const memoryCleanupInterval = setInterval(() => {
        try {
          if (window.gc) {
            window.gc();
          }

          const observers = ["modalObserver", "modalContentObserver"];
          observers.forEach((key) => {
            const observer = state[key];
            if (observer && observer._isDisconnected) {
              state[key] = null;
            }
          });

          const intervals = [
            "modalStatusCheckInterval",
            "urlCheckInterval",
            "modalCheckInterval",
          ];

          intervals.forEach((intervalKey) => {
            const interval = state[intervalKey];
            if (interval && typeof interval === "number") {
              clearInterval(interval);
              state[intervalKey] = null;
            }
          });

          if (DEBUG_MODE) {
            console.log("Periodic memory cleanup completed");
          }
        } catch (error) {
          if (DEBUG_MODE) {
            console.log("Error during memory cleanup:", error);
          }
        }
      }, 300000);

      state.memoryCleanupInterval = memoryCleanupInterval;

      window.addEventListener("beforeunload", () => {
        const memoryInterval = state.memoryCleanupInterval;
        if (memoryInterval) {
          clearInterval(memoryInterval);
        }
        stopStatsUpdates();
      });
    } catch (error) {
      console.error("Content script initialization error:", error);
      if (attempts < state.maxInitAttempts) {
        setTimeout(initializeContentScript, 1000);
      } else {
        console.error(
          "Content script initialization failed permanently after",
          state.maxInitAttempts,
          "attempts"
        );
      }
    }
  }

  function waitForDOMReady() {
    return new Promise((resolve) => {
      if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", resolve);
      } else {
        resolve();
      }
    });
  }

  waitForDOMReady().then(() => {
    initializeContentScript();
  });

  setTimeout(() => {
    if (!state.isInitialized) {
      initializeContentScript();
    }
  }, 1000);

  window.addEventListener("load", () => {
    if (!state.isInitialized) {
      initializeContentScript();
    }
  });

  // ✅ FIX #1: Removed duplicate observer check (was lines 408-414)
  function setupModalDetectionObserver() {
    if (state.modalObserver) {
      state.modalObserver.disconnect();
      state.modalObserver = null;
    }

    const targetSelectors = [
      "body",
      '[role="main"]',
      '[data-pagelet="Root"]',
      '[data-visualcompletion="ignore-dynamic"]',
      "[data-instancekey]",
    ];

    let targetElement = null;
    for (const selector of targetSelectors) {
      targetElement = document.querySelector(selector);
      if (targetElement) break;
    }

    if (!targetElement) {
      targetElement = document.body;
    }

    // ✅ FIX #5: Added debouncing to prevent race conditions
    const modalObserver = new MutationObserver((mutations) => {
      let hasNewNodes = false;
      const addedElements = [];

      for (const mutation of mutations) {
        if (mutation.type === "childList" && mutation.addedNodes.length > 0) {
          hasNewNodes = true;
          for (const node of mutation.addedNodes) {
            if (node.nodeType === Node.ELEMENT_NODE) {
              addedElements.push(node);
            }
          }
        }
      }

      if (!hasNewNodes || addedElements.length === 0) return;

      if (modalObserver._processingTimer) {
        clearTimeout(modalObserver._processingTimer);
      }

      modalObserver._processingTimer = setTimeout(() => {
        processAddedElements(addedElements);
      }, 5);
    });

    modalObserver.observe(targetElement, {
      childList: true,
      subtree: false,
    });

    state.modalObserver = modalObserver;

    function processAddedElements(elements) {
      for (const element of elements) {
        if (
          element.matches('[role="dialog"]') ||
          element.matches('[aria-modal="true"]') ||
          element.matches('div[data-visualcompletion="ignore-dynamic"]') ||
          element.matches("div[data-pagelet][data-visualcompletion]") ||
          element.querySelector('[role="dialog"]') ||
          element.querySelector('[aria-modal="true"]') ||
          element.querySelector('div[data-visualcompletion="ignore-dynamic"]')
        ) {
          if (DEBUG_MODE)
            console.log("Modal detected via optimized observer:", element);

          handleModalDetection(element);
        }
      }
    }

    function handleModalDetection(_modalElement) {
      const modalStatus = checkModalStatus();
      if (modalStatus.modalDetected && modalStatus.modalType === "Comments") {
        if (DEBUG_MODE) {
          console.log("[MODAL_OBSERVER] Comments modal detected");
        }

        state.lastModalStatus = modalStatus;

        const postInfo = extractCurrentPostInfo();
        if (postInfo) {
          handlePostChange(postInfo);
        }

        startStatsUpdates();
        startDynamicCommentCounting();
      } else {
        stopDynamicCommentCounting();
      }
    }
  }

  // ✅ FIX #3 & #16: Consistent naming and added stop function
  function setupFeedPostObserver() {
    if (state.feedObserver) return; // ✅ Use consistent property name

    const targetSelectors = [
      '[role="main"]',
      '[data-pagelet="Feed"]',
      "#contentArea",
      ".home",
      'div[data-pagelet*="Feed"]',
    ];

    let targetElement = null;
    for (const selector of targetSelectors) {
      targetElement = document.querySelector(selector);
      if (targetElement) break;
    }

    if (!targetElement) {
      targetElement = document.body;
    }

    const feedPostObserver = new MutationObserver((mutations) => {
      if (state.lastModalStatus?.modalDetected) return;

      let hasNewNodes = false;
      const addedElements = [];

      for (const mutation of mutations) {
        if (mutation.type === "childList" && mutation.addedNodes.length > 0) {
          hasNewNodes = true;
          for (const node of mutation.addedNodes) {
            if (node.nodeType === Node.ELEMENT_NODE) {
              addedElements.push(node);
            }
          }
        }
      }

      if (!hasNewNodes || addedElements.length === 0) return;

      if (feedPostObserver._processingTimer) {
        clearTimeout(feedPostObserver._processingTimer);
      }

      feedPostObserver._processingTimer = setTimeout(() => {
        processFeedElements(addedElements);
      }, 25);
    });

    feedPostObserver.observe(targetElement, {
      childList: true,
      subtree: false,
    });

    state.feedObserver = feedPostObserver; // ✅ Consistent naming

    function processFeedElements(elements) {
      for (const element of elements) {
        if (
          element.matches('[data-pagelet*="FeedUnit"]') ||
          element.matches("[data-story-id]") ||
          element.querySelector('[data-pagelet*="FeedUnit"]') ||
          element.querySelector("[data-story-id]")
        ) {
          if (DEBUG_MODE)
            console.log("Feed post detected via optimized observer:", element);

          handleFeedPostDetection(element);
        }
      }
    }

    function handleFeedPostDetection(postElement) {
      const postId =
        postElement.getAttribute("data-story-id") ||
        postElement
          .getAttribute("data-pagelet")
          ?.match(/FeedUnit_(\d+)/)?.[1] ||
        postElement.getAttribute("data-pagelet")?.match(/Story_(\d+)/)?.[1];

      if (postId && postId !== state.currentPostId) {
        if (DEBUG_MODE) {
          console.log(`[FEED_OBSERVER] New post detected: ${postId}`);
        }

        if (feedPostObserver._debounceTimer) {
          clearTimeout(feedPostObserver._debounceTimer);
        }

        feedPostObserver._debounceTimer = setTimeout(() => {
          try {
            const postInfo = extractCurrentPostInfo();
            if (postInfo && postInfo.postId === postId) {
              handlePostChange(postInfo);
            }
          } catch (error) {
            if (DEBUG_MODE) {
              console.log("Error in feed post detection:", error);
            }
          }
        }, 25);
      }
    }

    window.addEventListener("beforeunload", () => {
      const observer = state.feedObserver;
      if (observer) {
        if (observer._processingTimer) {
          clearTimeout(observer._processingTimer);
        }
        if (observer._debounceTimer) {
          clearTimeout(observer._debounceTimer);
        }
        observer.disconnect();
        state.feedObserver = null;
      }
    });

    if (DEBUG_MODE) {
      console.log("Optimized feed post observer set up");
    }
  }

  // ✅ FIX #23: Removed unused _fallbackMessage parameter (now has underscore)
  function safeSendMessage(message, _fallbackMessage = null) {
    if (
      typeof chrome !== "undefined" &&
      chrome.runtime &&
      chrome.runtime.sendMessage
    ) {
      try {
        chrome.runtime.sendMessage(message).catch((error) => {
          if (
            error.message.includes("Extension context invalidated") ||
            error.message.includes("Receiving end does not exist") ||
            error.message.includes("Could not establish connection")
          ) {
            if (DEBUG_MODE) {
              console.warn(
                "Extension context error - message not sent:",
                error.message
              );
            }
            return;
          }

          if (DEBUG_MODE) {
            console.log("Message send failed:", error);
          }
        });
      } catch (syncError) {
        if (DEBUG_MODE) {
          console.warn("Synchronous message send error:", syncError.message);
        }
      }
    }
  }

  // ✅ FIX #24: Extracted duplicate comment counting logic to separate function
  function countCommentsInModal() {
    const modal =
      document.querySelector('[role="dialog"]') ||
      document.querySelector('[aria-modal="true"]') ||
      document.querySelector("div[data-pagelet][data-visualcompletion]") ||
      document.querySelector('div[data-visualcompletion="ignore-dynamic"]');

    if (!modal) return 0;

    const commentSelectors = [
      '[data-testid*="UFI2Comment"]',
      '[data-testid*="CommentListItem"]',
      '[data-pagelet*="Comment"]',
      'div[data-visualcompletion] > div[role="article"]',
      "div[data-commentid]",
      '[data-sigil*="comment"]',
      '[data-testid*="comment"]',
    ];

    const uniqueComments = new Set();

    for (const selector of commentSelectors) {
      const elements = modal.querySelectorAll(selector);
      elements.forEach((element) => {
        const commentId =
          element.getAttribute("data-commentid") ||
          element.getAttribute("data-testid") ||
          element.id ||
          element.getAttribute("data-pagelet") ||
          element.textContent?.substring(0, 50);

        if (commentId && !uniqueComments.has(commentId)) {
          const text = element.textContent?.trim() || "";
          const hasProfileLink = element.querySelector(
            'a[href*="facebook.com"], a[href^="/"]'
          );
          const hasCommentIndicators =
            text.length > 10 &&
            (hasProfileLink ||
              text.includes("·") ||
              element.querySelector("strong, b, .fwb") ||
              element.querySelector('span[dir="auto"]'));

          if (hasCommentIndicators) {
            uniqueComments.add(commentId);
          }
        }
      });
    }

    let totalComments = uniqueComments.size;

    if (totalComments < 3) {
      const simpleCount = modal.querySelectorAll(
        'div[role="article"], [data-commentid], [data-testid*="comment"]'
      ).length;
      if (simpleCount > totalComments) {
        totalComments = simpleCount;
      }
    }

    if (DEBUG_MODE) {
      console.log(
        `Comment count: ${totalComments} (from ${uniqueComments.size} unique elements)`
      );
    }

    return totalComments;
  }

  // ✅ FIX #7: Proper async handling - wrapped in async IIFE and return true
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    // Handle async operations properly
    (async () => {
      try {
        if (request.action === "ping") {
          sendResponse({
            pong: true,
            initialized: state.isInitialized,
            url: window.location.href,
            readyState: document.readyState,
            debugMode: DEBUG_MODE,
          });
          return;
        }

        if (request.action === "setDebugMode") {
          state.debugMode = request.enabled || false;
          DEBUG_MODE = state.debugMode; // ✅ FIX #19: Keep synced
          if (typeof chrome !== "undefined" && chrome.storage) {
            chrome.storage.local.set({
              debugMode: state.debugMode,
            });
          }
          sendResponse({
            success: true,
            debugMode: state.debugMode,
          });
          return;
        }

        if (request.action === "setCooldownSetting") {
          const newCooldown = Math.max(
            5,
            Math.min(300, request.cooldown || 25)
          );
          state.cooldownSetting = newCooldown;
          if (typeof chrome !== "undefined" && chrome.storage) {
            chrome.storage.local.set({ cooldownSetting: newCooldown });
          }
          sendResponse({ success: true, cooldownSetting: newCooldown });
          return;
        }

        if (request.action === "setExtractionCountLimit") {
          const newLimit = Math.max(50, Math.min(2000, request.limit || 500));
          state.extractionCountLimit = newLimit;
          if (typeof chrome !== "undefined" && chrome.storage) {
            chrome.storage.local.set({ extractionCountLimit: newLimit });
          }
          sendResponse({ success: true, extractionCountLimit: newLimit });
          return;
        }

        if (request.action === "checkModalStatus") {
          try {
            const modalStatus = checkModalStatus();

            const modalChanged =
              modalStatus.modalDetected !==
                state.lastModalStatus.modalDetected ||
              modalStatus.postId !== state.lastModalStatus.postId;
            if (modalChanged) {
              if (DEBUG_MODE)
                console.log(
                  "Modal status changed:",
                  state.lastModalStatus,
                  "->",
                  modalStatus
                );
              state.lastModalStatus = modalStatus;

              if (
                !modalStatus.modalDetected &&
                state.lastModalStatus.modalDetected
              ) {
                if (DEBUG_MODE)
                  console.log(
                    "Modal closed, will update post detection on next check"
                  );
              }
            }

            if (DEBUG_MODE) console.log("Modal status result:", modalStatus);

            const extractedUsernames = state.extractedUsernames;
            const totalExtracted = extractedUsernames.size;
            const lastExtractionTime = state.lastExtractionTime;
            const extractionCount = state.extractionCount;
            const cooldownSetting = state.cooldownSetting;

            const now = Date.now();
            const timeSinceLastExtraction = now - lastExtractionTime;
            const isInCooldown =
              extractionCount >= 5 &&
              timeSinceLastExtraction < cooldownSetting * 1000;
            const remainingTime = isInCooldown
              ? Math.ceil(
                  (cooldownSetting * 1000 - timeSinceLastExtraction) / 1000
                )
              : 0;

            // ✅ FIX #24: Use extracted function
            let totalComments = 0;
            if (
              modalStatus.modalDetected &&
              modalStatus.modalType === "Comments"
            ) {
              totalComments = countCommentsInModal();
            }

            const response = {
              ...modalStatus,
              totalComments,
              totalExtracted,
              isInCooldown,
              remainingTime,
            };
            if (response && response.error) {
              console.error("Content script error:", response.error);
              sendResponse(response);
              return;
            }

            sendResponse(response);
          } catch (checkError) {
            console.error("Error in checkModalStatus:", checkError);
            sendResponse({
              modalDetected: false,
              modalType: null,
              postTitle: null,
              totalComments: 0,
              totalExtracted: 0,
              error: "Modal check failed: " + checkError.message,
            });
          }
          return;
        }

        if (request.action === "debugFacebookHealth") {
          const healthStatus = checkFacebookPageHealth();
          const currentPost = extractCurrentPostInfo();
          const modalStatus = checkModalStatus();

          const modal =
            document.querySelector('[role="dialog"]') ||
            document.querySelector('[aria-modal="true"]') ||
            document.querySelector(
              'div[data-visualcompletion="ignore-dynamic"]'
            ) ||
            document.querySelector("div[data-pagelet][data-visualcompletion]");

          let commentCount = 0;
          let profileLinkCount = 0;
          if (modal) {
            commentCount = modal.querySelectorAll(
              '[data-testid*="comment"], div[role="article"], [data-commentid]'
            ).length;
            profileLinkCount = modal.querySelectorAll(
              'a[href*="facebook.com"], a[href^="/"]'
            ).length;
          }

          sendResponse({
            healthStatus,
            currentPost,
            modalStatus,
            debugInfo: {
              modalFound: !!modal,
              commentCount,
              profileLinkCount,
              modalSelectors: {
                roleDialog: !!document.querySelector('[role="dialog"]'),
                ariaModal: !!document.querySelector('[aria-modal="true"]'),
                visualCompletion: !!document.querySelector(
                  'div[data-visualcompletion="ignore-dynamic"]'
                ),
                pageletVisual: !!document.querySelector(
                  "div[data-pagelet][data-visualcompletion]"
                ),
              },
            },
            timestamp: new Date().toISOString(),
            userAgent: navigator.userAgent,
            url: window.location.href,
            readyState: document.readyState,
          });
          return;
        }

        if (request.action === "extractComments") {
          console.log("Content script received extractComments message");
          try {
            console.log("Starting comment extraction...");
            const result = await extractFromComments();
            console.log("Extraction result:", result);
            sendResponse(result);
          } catch (err) {
            console.error("Extraction error:", err);
            sendResponse({
              error: "Internal content script error: " + err?.message,
              mentions: [],
              modalDetected: false,
            });
          }
          return;
        }

        if (request.action === "forcePostDetection") {
          const currentPost = extractCurrentPostInfo();
          if (DEBUG_MODE)
            console.log("Force post detection result:", currentPost);

          if (currentPost) {
            const lastObservedPost = state.lastObservedPost;
            const postChanged =
              !lastObservedPost ||
              currentPost.signature !== lastObservedPost.signature;
            if (postChanged) {
              if (DEBUG_MODE) console.log("Force detection: Post changed");
              handlePostChange(currentPost);
              safeSendMessage({
                action: "postChanged",
                oldPost: lastObservedPost,
                newPost: currentPost,
              });
            } else {
              handlePostChange(currentPost);
            }
            state.lastObservedPost = currentPost;
          }

          sendResponse({
            success: true,
            postDetected: !!currentPost,
            postInfo: currentPost,
          });
          return;
        }

        if (request.action === "clearExtractedUsernames") {
          state.extractedUsernames = new Set();
          state.extractionCount = 0;
          state.lastExtractionTime = 0;
          if (typeof chrome !== "undefined" && chrome.storage) {
            chrome.storage.local.set({
              extractedUsernames: [],
              extractionCount: 0,
              lastExtractionTime: 0,
            });
          }
          sendResponse({ success: true, totalExtracted: 0 });
          return;
        }

        if (request.action === "resetExtractionState") {
          state.extractedUsernames = new Set();
          state.extractionCount = 0;
          state.lastExtractionTime = 0;
          sendResponse({ success: true });
          return;
        }

        if (request.action === "globalReset") {
          console.log("Performing global reset...");

          const modalObserver = state.modalObserver;
          if (modalObserver) {
            modalObserver.disconnect();
            state.modalObserver = null;
          }

          const modalContentObserver = state.modalContentObserver;
          if (modalContentObserver) {
            if (modalContentObserver._debounceTimer) {
              clearTimeout(modalContentObserver._debounceTimer);
            }
            modalContentObserver.disconnect();
            state.modalContentObserver = null;
          }

          const intervals = [
            "modalStatusCheckInterval",
            "urlCheckInterval",
            "modalCheckInterval",
            "memoryCleanupInterval",
          ];

          intervals.forEach((intervalKey) => {
            const interval = state[intervalKey];
            if (interval) {
              clearInterval(interval);
              state[intervalKey] = null;
            }
          });

          state.isInitialized = false;
          state.lastModalStatus = {
            modalDetected: false,
            modalType: null,
            postId: null,
          };
          state.lastObservedPost = null;
          state.currentPostId = null;
          state.posterName = null;
          state.lastDomStructureHash = null;
          state.domChangeCount = 0;
          state.domWarningShown = false;

          state.modalPostInfo = null;
          state.modalPostDetected = false;

          state.extractedUsernames = new Set();
          state.extractionCount = 0;
          state.lastExtractionTime = 0;

          stopDynamicCommentCounting();

          // ✅ FIX #15: Set defaults in callback to prevent race condition
          if (typeof chrome !== "undefined" && chrome.storage) {
            chrome.storage.local.clear(() => {
              if (chrome.runtime.lastError) {
                console.error(
                  "Error clearing storage:",
                  chrome.runtime.lastError
                );
              } else {
                const defaultValues = {
                  debugMode: false,
                  cooldownSetting: 25,
                  extractionCountLimit: 50,
                  extractedUsernames: [],
                  extractionCount: 0,
                  lastExtractionTime: 0,
                };
                chrome.storage.local.set(defaultValues, () => {
                  if (chrome.runtime.lastError) {
                    console.error(
                      "Error setting default storage values:",
                      chrome.runtime.lastError
                    );
                  } else {
                    console.log("Storage reset to default values");
                  }
                });
              }
            });
          }

          setTimeout(() => {
            if (!state.isInitialized) {
              initializeContentScript();
            }
          }, 1000);

          sendResponse({
            success: true,
            message:
              "Global reset completed - all states restored to initial values",
          });
          return;
        }

        sendResponse({ error: "Unknown action: " + request.action });
      } catch (err) {
        console.error("Message handler error:", err);
        sendResponse({
          error: err.message,
          mentions: [],
          modalDetected: false,
        });
      }
    })();

    // ✅ FIX #7: Return true to keep message channel open for async responses
    return true;
  });

  // ✅ FIX #8 & #22: Optimized with timeout protection and query once
  function checkModalStatus() {
    try {
      const startTime = Date.now();
      const maxTime = 5000; // ✅ FIX #8: 5 second timeout protection

      const modalSelectors = [
        '[role="dialog"]',
        '[aria-modal="true"]',
        'div[data-visualcompletion="ignore-dynamic"]',
        "div[data-pagelet][data-visualcompletion]",
        'div[data-visualcompletion*="dialog"]',
        'div[data-pagelet*="Dialog"]',
        'div[data-testid*="modal"]',
        'div[data-testid*="dialog"]',
        "[data-instancekey]",
        'div[data-visualcompletion*="modal"]',
        'div[data-pagelet*="Modal"]',
        'div[role="dialog"]',
        'div[aria-modal="true"]',
        'div[data-pagelet*="FeedUnit"]',
        'div[data-pagelet*="Story"]',
      ];

      // ✅ FIX #22: Query once and reuse
      let modal = null;
      let modalType = null;
      let postTitle = null;
      let posterName = null;
      let postId = null;

      for (const selector of modalSelectors) {
        if (Date.now() - startTime > maxTime) break; // ✅ Timeout check
        modal = document.querySelector(selector);
        if (modal) break;
      }

      if (!modal) {
        return {
          modalDetected: false,
          modalType: null,
          postTitle: null,
          posterName: null,
          postId: null,
          totalComments: 0,
        };
      }

      const commentElements = modal.querySelectorAll(`
        [data-testid*="UFI2Comment"],
        [data-testid*="CommentListItem"],
        [data-pagelet*="Comment"],
        div[data-visualcompletion] > div[role="article"],
        div[data-commentid],
        [data-sigil*="comment"],
        [data-testid*="comment"],
        [data-testid*="CommentsList"],
        [data-pagelet*="Comments"],
        div[data-visualcompletion*="comment"],
        [aria-label*="comment"],
        [aria-label*="reply"],
        [data-testid*="Comment"],
        [data-pagelet*="Comment"],
        div[data-ft*="comment"],
        div[data-store*="comment"],
        form.comment-form,
        textarea[placeholder*="comment"],
        textarea[placeholder*="reply"],
        div[data-testid*="comment"],
        article[data-testid*="comment"]
      `);

      const hasComments = commentElements.length > 0;
      modalType = hasComments ? "Comments" : "Unknown";

      if (modalType === "Comments") {
        const titleSelectors = [
          'h2[data-testid="post_message"]',
          'div[data-testid="post_message"] h2',
          'span[data-testid="post_message"]',
          '[data-ad-preview="message"]',
          'div[data-pagelet="FeedUnit_0"] h2',
          'div[data-pagelet="FeedUnit_0"] span[dir="auto"]',
          'div[data-pagelet="FeedUnit_0"] div[dir="auto"]',
          'div[data-pagelet*="Story"] h2',
          'div[data-pagelet*="Story"] span[dir="auto"]',
          'div[data-pagelet*="Story"] div[dir="auto"]',
          'h1[data-testid="post_message"]',
          'h3[data-testid="post_message"]',
          'h4[data-testid="post_message"]',
        ];

        for (const selector of titleSelectors) {
          if (Date.now() - startTime > maxTime) break;
          const titleEl = modal.querySelector(selector);
          if (titleEl?.textContent?.trim()) {
            const text = titleEl.textContent.trim();
            const isInComment = titleEl.closest(
              '[data-commentid], [data-testid*="comment"], [data-sigil*="comment"]'
            );
            const parentElement = titleEl.closest(
              '[data-pagelet], article, [role="article"]'
            );
            const isInPostArea =
              parentElement &&
              (parentElement
                .getAttribute("data-pagelet")
                ?.includes("FeedUnit") ||
                parentElement.getAttribute("data-pagelet")?.includes("Story") ||
                parentElement.matches("article") ||
                parentElement.matches('[role="article"]'));

            if (!isInComment && (isInPostArea || text.length > 20)) {
              postTitle =
                text.length > 100 ? text.substring(0, 97) + "..." : text;
              break;
            }
          }
        }

        if (!postTitle) postTitle = "Facebook Post";

        const posterSelectors = [
          'a[href*="facebook.com"]:not([href*="groups/"]):not([href*="pages/"]):not([href*="events/"]):not([href*="photos/"]):not([href*="videos/"]):not([href*="posts/"]):not([href*="permalink/"]):not([href*="watch"])',
          'strong a[href*="facebook.com"]',
          'b a[href*="facebook.com"]',
          'h3 a[href*="facebook.com"]',
          'strong:not([data-testid="post_message"] *)',
          'b:not([data-testid="post_message"] *)',
          'h3:not([data-testid="post_message"] *)',
        ];

        for (const selector of posterSelectors) {
          if (Date.now() - startTime > maxTime) break;
          const elements = modal.querySelectorAll(selector);
          for (const element of elements) {
            let name = null;
            if (element.tagName === "A") {
              name = element.textContent.trim();
            } else {
              const link = element.querySelector('a[href*="facebook.com"]');
              name = link
                ? link.textContent.trim()
                : element.textContent.trim();
            }

            if (
              name &&
              name.length >= 2 &&
              name.length <= 50 &&
              !name.includes("http") &&
              !name.includes("@") &&
              !name.includes("#") &&
              !name.includes("...") &&
              name !== postTitle.substring(0, name.length)
            ) {
              posterName = name;
              break;
            }
          }
          if (posterName) break;
        }

        if (!posterName) posterName = "User";

        const idSelectors = [
          "[data-story-id]",
          '[data-ft*="top_level_post_id"]',
          'div[data-pagelet*="FeedUnit"]',
          '[data-testid*="post"]',
          'div[data-pagelet*="Story"]',
          'div[data-visualcompletion*="story"]',
          '[data-testid*="story"]',
        ];

        for (const selector of idSelectors) {
          if (Date.now() - startTime > maxTime) break;
          const element = modal.querySelector(selector);
          if (element) {
            postId =
              element.getAttribute("data-story-id") ||
              element
                .getAttribute("data-ft")
                ?.match(/"top_level_post_id":"(\d+)"/)?.[1] ||
              element
                .getAttribute("data-pagelet")
                ?.match(/FeedUnit_(\d+)/)?.[1] ||
              element.getAttribute("data-pagelet")?.match(/Story_(\d+)/)?.[1] ||
              element.getAttribute("data-testid")?.match(/post_(\d+)/)?.[1] ||
              element.getAttribute("data-testid")?.match(/story_(\d+)/)?.[1];
            if (postId) break;
          }
        }

        if (!postId) {
          const urlPatterns = [
            /\/posts\/(\d+)/,
            /\/permalink\/(\d+)/,
            /story_fbid=(\d+)/,
            /\/(\d+)\//,
          ];
          for (const pattern of urlPatterns) {
            const match = window.location.href.match(pattern);
            if (match) {
              postId = match[1];
              break;
            }
          }
        }

        if (!postId) {
          postId = "modal_" + Date.now().toString().slice(-8);
        }
      }

      let totalComments = 0;
      if (modalType === "Comments") {
        const uniqueComments = new Set();

        for (const element of commentElements) {
          if (Date.now() - startTime > maxTime) break; // ✅ Timeout check
          const commentId =
            element.getAttribute("data-commentid") ||
            element.getAttribute("data-testid") ||
            element.id ||
            element.getAttribute("data-pagelet") ||
            element.textContent?.substring(0, 50);

          if (commentId) {
            const text = element.textContent?.trim() || "";
            const hasProfileLink = element.querySelector(
              'a[href*="facebook.com"], a[href^="/"]'
            );
            const hasCommentIndicators =
              text.length > 10 &&
              (hasProfileLink ||
                text.includes("·") ||
                element.querySelector("strong, b, .fwb") ||
                element.querySelector('span[dir="auto"]'));

            if (hasCommentIndicators && !uniqueComments.has(commentId)) {
              uniqueComments.add(commentId);
            }
          }
        }

        totalComments = uniqueComments.size;

        if (totalComments < 3) {
          const simpleCount = modal.querySelectorAll(
            'div[role="article"], [data-commentid], [data-testid*="comment"]'
          ).length;
          if (simpleCount > totalComments) {
            totalComments = simpleCount;
          }
        }
      }

      return {
        modalDetected: true,
        modalType,
        postTitle,
        posterName,
        postId,
        totalComments,
      };
    } catch (error) {
      // ✅ FIX #21: Log error when DEBUG_MODE before returning null
      if (DEBUG_MODE) console.error("Modal status check error:", error);
      return {
        modalDetected: false,
        modalType: null,
        postTitle: null,
        posterName: null,
        postId: null,
        totalComments: 0,
        error: error.message,
      };
    }
  }

  // ✅ FIX #9: Added timeout protection (3 seconds max) and single click only
  async function loadMoreContentFast(modal) {
    try {
      const startTime = Date.now();
      const maxTime = 3000; // ✅ Maximum 3 seconds
      let clicked = false;

      const buttons = modal.querySelectorAll(
        'button, [role="button"], a, [data-testid*="see-more"], [data-testid*="load-more"]'
      );

      for (const button of buttons) {
        if (Date.now() - startTime > maxTime) break; // ✅ Timeout check

        const text = button.textContent?.toLowerCase() || "";
        const ariaLabel =
          button.getAttribute("aria-label")?.toLowerCase() || "";

        if (
          text.includes("see more") ||
          text.includes("load more") ||
          text.includes("view more") ||
          text.includes("expand") ||
          text.includes("more comments") ||
          text.includes("more replies") ||
          ariaLabel.includes("see more") ||
          ariaLabel.includes("load more") ||
          ariaLabel.includes("view more")
        ) {
          try {
            button.click();
            clicked = true;
            await wait(25);
          } catch {
            // Ignore click failures
          }
        }
      }

      if (clicked) {
        const remainingTime = maxTime - (Date.now() - startTime);
        if (remainingTime > 100) {
          modal.scrollTop = modal.scrollHeight;
          await wait(25);
          modal.scrollTop = modal.scrollHeight / 2;
          await wait(25);
        }
      }
    } catch {
      // Silent fail
    }
  }

  // ✅ FIX #10: Enforced 10-second timeout with checks
  function extractUsernamesFast(modal, extractedUsernames, maxUsernames = 200) {
    const usernames = new Set();
    const startTime = Date.now();
    const maxTime = 10000; // ✅ Maximum 10 seconds

    try {
      const allElements = modal.querySelectorAll(`
        a[href*="facebook.com"]:not([href*="groups/"]):not([href*="pages/"]):not([href*="events/"]):not([href*="photos/"]):not([href*="videos/"]):not([href*="posts/"]):not([href*="permalink/"]):not([href*="watch"]),
        a[href^="/"]:not([href^="//"]),
        strong:not([data-testid="post_message"] *),
        b:not([data-testid="post_message"] *),
        h3:not([data-testid="post_message"] *),
        .fwb,
        [data-hovercard-user-id]
      `);

      const maxElements = Math.min(allElements.length, 2000);

      for (let i = 0; i < maxElements; i++) {
        // ✅ FIX #10: Check time limit every iteration
        if (Date.now() - startTime > maxTime) {
          if (DEBUG_MODE)
            console.log(`Extraction timed out after processing ${i} elements`);
          break;
        }

        const element = allElements[i];

        const commentContainer = element.closest(
          '[data-testid*="comment"], div[role="article"], [data-commentid], [data-testid*="Comment"], [data-pagelet*="Comment"]'
        );
        if (!commentContainer) continue;

        const text = (element.textContent || "").trim().toLowerCase();
        if (
          text.includes("like") ||
          text.includes("love") ||
          text.includes("haha") ||
          text.includes("wow") ||
          text.includes("sad") ||
          text.includes("angry") ||
          text.includes("see more") ||
          text.includes("load more") ||
          text.includes("reply")
        ) {
          continue;
        }

        let username = "";

        const userId = element.getAttribute("data-hovercard-user-id");
        if (userId && /^\d+$/.test(userId)) {
          username = userId;
        }

        if (!username) {
          const href = element.getAttribute("href");
          if (href) {
            try {
              const url = href.startsWith("http")
                ? new URL(href)
                : new URL(href, "https://facebook.com");
              const pathParts = url.pathname
                .replace(/^\//, "")
                .split("/")
                .filter((p) => p);
              if (
                pathParts.length > 0 &&
                pathParts[0] !== "profile.php" &&
                pathParts[0] !== "user.php"
              ) {
                username = pathParts[0];
              }
            } catch {
              // Ignore URL parsing errors
            }
          }
        }

        if (!username) {
          const text = (element.textContent || "").trim();
          if (
            text &&
            text.length >= 2 &&
            text.length <= 50 &&
            !text.includes("http") &&
            !text.includes("@") &&
            !text.includes("#")
          ) {
            username = text
              .replace(/[^\p{L}\p{N}\s._-]/gu, "")
              .trim()
              .replace(/\s+/g, ".");
          }
        }

        if (
          username &&
          isValidUsernameFast(username, extractedUsernames) &&
          !usernames.has(username)
        ) {
          usernames.add(username);
          if (usernames.size >= maxUsernames) break;
        }
      }
    } catch (error) {
      if (DEBUG_MODE) console.log("Username extraction error:", error);
    }

    if (DEBUG_MODE) {
      console.log(
        `Extracted ${usernames.size} usernames in ${Date.now() - startTime}ms`
      );
    }

    return Array.from(usernames);
  }

  function isValidUsernameFast(username, extractedUsernames) {
    if (!username || typeof username !== "string") return false;
    if (username.length < 2 || username.length > 50) return false;
    if (!/^[\p{L}0-9._-]+$/u.test(username)) return false;
    if (/^\d+$/.test(username)) return false;
    if (username === "profile.php" || username === "user.php") return false;
    if (extractedUsernames.has(username)) return false;
    return true;
  }

  // ✅ FIX #14: Removed setTimeout, use synchronous storage
  function updateStorageFast(
    extractedUsernames,
    lastExtractionTime,
    extractionCount
  ) {
    try {
      const dataToStore = {
        extractedUsernames: Array.from(extractedUsernames),
        lastExtractionTime,
        extractionCount,
      };

      chrome.storage.local.set(dataToStore, () => {
        if (chrome.runtime.lastError && DEBUG_MODE) {
          console.log("Storage save error:", chrome.runtime.lastError.message);
        }
      });
    } catch {
      // Silent fail
    }
  }

  async function loadAllComments(modal) {
    for (let i = 0; i < 5; i++) {
      modal.scrollTop = modal.scrollHeight;
      await wait(1000);
      await loadMoreContentFast(modal);
      await wait(1000);
    }
  }

  async function extractFromComments() {
    const mentions = [];
    const seen = new Set();
    let modalInfo = null;

    try {
      modalInfo = checkModalStatus();
      if (!modalInfo.modalDetected || modalInfo.modalType !== "Comments") {
        return {
          mentions: [],
          modalDetected: modalInfo.modalDetected,
          modalType: modalInfo.modalType,
          postTitle: modalInfo.postTitle,
          posterName: modalInfo.posterName,
          error: "Comments modal not detected",
        };
      }

      const extractedUsernames = state.extractedUsernames;
      const lastExtractionTime = state.lastExtractionTime;
      const extractionCount = state.extractionCount;
      const extractionCountLimit = state.extractionCountLimit;

      const now = Date.now();
      const timeSinceLastExtraction = now - lastExtractionTime;

      const resetCount = timeSinceLastExtraction > 600000;
      const currentCount = resetCount ? 0 : extractionCount;

      const modal =
        document.querySelector('[role="dialog"]') ||
        document.querySelector('[aria-modal="true"]') ||
        document.querySelector("div[data-pagelet][data-visualcompletion]") ||
        document.querySelector('div[data-visualcompletion="ignore-dynamic"]');

      if (!modal) {
        return {
          mentions: [],
          modalDetected: false,
          postTitle: modalInfo.postTitle,
          posterName: modalInfo.posterName,
          error: "Modal element not found",
        };
      }

      await loadAllComments(modal);

      const commenterLinks = extractUsernamesFast(
        modal,
        extractedUsernames,
        extractionCountLimit
      );

      if (DEBUG_MODE) {
        console.log(
          `Found ${commenterLinks.length} commenter links to process`
        );
      }

      for (const username of commenterLinks) {
        if (mentions.length >= extractionCountLimit) break;

        if (isValidUsernameFast(username, extractedUsernames)) {
          mentions.push(`@${username}`);
          seen.add(username);
          state.extractedUsernames.add(username);
          if (DEBUG_MODE) console.log(`✓ Added valid username: @${username}`); // ✅ FIX #20: Simple checkmark
        }
      }

      const newCount = currentCount + mentions.length;
      state.lastExtractionTime = now;
      state.extractionCount = newCount;

      updateStorageFast(extractedUsernames, now, newCount);

      const finalResult = {
        mentions,
        modalDetected: true,
        modalType: "Comments",
        postTitle: modalInfo.postTitle,
        posterName: modalInfo.posterName,
        extractionCount: newCount,
        totalExtracted: state.extractedUsernames.size,
        totalComments: commenterLinks.length,
      };

      console.log(
        `Returning ${mentions.length} mentions from extractFromComments`
      );
      return finalResult;
    } catch (error) {
      // ✅ FIX #21: Log error when DEBUG_MODE
      if (DEBUG_MODE) console.error("Comments extraction error:", error);
      return {
        error: "Failed to extract comments: " + (error?.message || error),
        modalDetected: false,
        postTitle: modalInfo?.postTitle || null,
        posterName: modalInfo?.posterName || null,
        mentions: [],
      };
    }
  }

  function wait(ms) {
    return new Promise((res) => setTimeout(res, ms));
  }

  function extractPostInfoFromUrl(url) {
    try {
      const urlObj = new URL(url);

      let postId = null;
      let postType = "unknown";

      const postsMatch = urlObj.pathname.match(/\/posts\/(\d+)/);
      if (postsMatch) {
        postId = postsMatch[1];
        postType = "post";
      }

      const permalinkMatch = urlObj.pathname.match(/\/permalink\/(\d+)/);
      if (permalinkMatch) {
        postId = permalinkMatch[1];
        postType = "permalink";
      }

      const storyFbid = urlObj.searchParams.get("story_fbid");
      if (storyFbid) {
        postId = storyFbid;
        postType = "story";
      }

      const groupPermalinkMatch = urlObj.pathname.match(
        /\/groups\/\d+\/permalink\/(\d+)/
      );
      if (groupPermalinkMatch) {
        postId = groupPermalinkMatch[1];
        postType = "group_post";
      }

      const groupPostsMatch = urlObj.pathname.match(
        /\/groups\/\d+\/posts\/(\d+)/
      );
      if (groupPostsMatch) {
        postId = groupPostsMatch[1];
        postType = "group_post";
      }

      const userPostsMatch = urlObj.pathname.match(/\/[^/]+\/posts\/(\d+)/);
      if (userPostsMatch) {
        postId = userPostsMatch[1];
        postType = "user_post";
      }

      const storyPhpMatch = urlObj.searchParams.get("story_fbid");
      if (storyPhpMatch && !postId) {
        postId = storyPhpMatch;
        postType = "story_php";
      }

      const photosMatch = urlObj.pathname.match(
        /\/[^/]+\/photos\/[^/]+\/(\d+)/
      );
      if (photosMatch) {
        postId = photosMatch[1];
        postType = "photo_post";
      }

      const watchVideoId = urlObj.searchParams.get("v");
      if (watchVideoId) {
        postId = watchVideoId;
        postType = "video";
      }

      const videoMatch = urlObj.pathname.match(/\/[^/]+\/videos\/(\d+)/);
      if (videoMatch) {
        postId = videoMatch[1];
        postType = "video";
      }

      const liveMatch = urlObj.pathname.match(/\/[^/]+\/live/);
      if (liveMatch) {
        postId = "live_" + Date.now();
        postType = "live";
      }

      if (postId) {
        const signature = `${postType}_${postId}_${urlObj.pathname}_${
          urlObj.search
        }_${Date.now()}`;

        return {
          postId,
          title: `Facebook ${postType.replace("_", " ")}`,
          signature,
          source: "url",
          url: url,
          postType,
        };
      }

      return null;
    } catch (error) {
      // ✅ FIX #21: Log when DEBUG_MODE
      if (DEBUG_MODE)
        console.log("Error extracting post info from URL:", error);
      return null;
    }
  }

  function extractCurrentPostInfo() {
    try {
      if (!document.body || document.readyState !== "complete") return null;

      const modalInfo = checkModalStatus();
      if (
        modalInfo.modalDetected &&
        modalInfo.modalType === "Comments" &&
        modalInfo.postId
      ) {
        return {
          postId: modalInfo.postId,
          title: modalInfo.postTitle || "Facebook Post",
          posterName: modalInfo.posterName || null,
          signature: `modal_${modalInfo.postId}_${Date.now()}`,
          source: "modal",
        };
      }

      const urlPostInfo = extractPostInfoFromUrl(window.location.href);
      if (urlPostInfo) return urlPostInfo;

      const postSelectors = [
        '[data-pagelet*="FeedUnit"]',
        "[data-story-id]",
        'div[data-ft*="top_level_post_id"]',
        '[data-testid*="post"]',
        "article[data-story-id]",
        'div[data-pagelet*="Story"]',
        'div[data-visualcompletion*="story"]',
        '[data-testid*="story"]',
        "[data-instancekey]",
        'div[data-visualcompletion*="feed"]',
        '[data-testid*="FeedUnit"]',
        'div[data-pagelet*="FeedUnit"]',
        "article",
        '[role="article"]',
      ];

      for (const selector of postSelectors) {
        const elements = document.querySelectorAll(selector);
        for (const element of elements) {
          const rect = element.getBoundingClientRect();
          if (rect.width === 0 || rect.height === 0) continue;

          const postId =
            element.getAttribute("data-story-id") ||
            element
              .getAttribute("data-pagelet")
              ?.match(/FeedUnit_(\d+)/)?.[1] ||
            element.getAttribute("data-pagelet")?.match(/Story_(\d+)/)?.[1] ||
            element
              .getAttribute("data-ft")
              ?.match(/"top_level_post_id":"(\d+)"/)?.[1];

          if (postId) {
            const titleEl = element.querySelector(
              '[data-testid="post_message"], h2, [data-ad-preview="message"]'
            );
            const title = titleEl?.textContent?.trim() || "Facebook Post";

            const posterEl = element.querySelector(
              'strong a[href*="facebook.com"], [data-testid*="actor"] a, strong'
            );
            const posterName = posterEl?.textContent?.trim() || null;

            return {
              postId,
              title:
                title.length > 100 ? title.substring(0, 97) + "..." : title,
              posterName,
              signature: `${postId}_${Date.now()}`,
              source: "dom",
            };
          }
        }
      }

      return null;
    } catch (error) {
      // ✅ FIX #21: Log when DEBUG_MODE
      if (DEBUG_MODE) console.error("Error extracting post info:", error);
      return null;
    }
  }
})();
